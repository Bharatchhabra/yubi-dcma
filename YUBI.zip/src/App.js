import logo from './logo.svg';
import './App.css';
import Header from './components/layout/header/Header';
import StepperPage from './components/Stepper/StepperPage';

function App() {
  return (
    <div className="App">
      <Header />
      <StepperPage />
    </div>
  );
}

export default App;
