import React, { useContext } from "react";
import { makeStyles } from "@material-ui/core";
import "./stepper.scss";
import Stepper from "react-stepper-horizontal";
import { LabelContext } from "./LabelDataContext";
import Validate from "../../pages/dcma/validate/Validate";
import Search from "../../pages/dcma/search/Search";
import Report from "../../pages/dcma/report/Report";
import Refine from "../../pages/dcma/refine/Refine";
import { Container } from "@material-ui/core";

// const useStyles = makeStyles((theme) => ({

//   dcma_stepper: {
//     paddingTop: "50px"
//   }
// }));

const StepperPage = (props) => {
  const value = useContext(LabelContext);
  console.log(value);
  return (
    <Container>
      <div className="dcma_stepper">        
          {value.page !== 3 && (
          <Stepper steps={value.steps} activeStep={value.page} />
        )}
        
        {value.page === 0 && <Search />}
        {value.page === 1 && <Refine />}
        {value.page === 2 && <Report />}
        {value.page === 3 && <Validate />}
         
        </div>
        
    </Container>
  );
};
export default StepperPage;
