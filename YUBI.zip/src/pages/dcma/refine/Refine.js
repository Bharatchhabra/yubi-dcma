import React from 'react'

function Refine() {
    return (
        <div>
            Refine
        </div>
    )
}

export default Refine
