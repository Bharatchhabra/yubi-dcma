import React from 'react'

function Validate() {
    return (
        <div>
            Validate
        </div>
    )
}

export default Validate
