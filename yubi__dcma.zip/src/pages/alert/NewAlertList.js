import React from "react";
import "./alert.scss";
import {
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Container,
  Avatar,
  Grid,
  InputBase,
  Button,
} from "@mui/material";
import DragIndicatorIcon from "@mui/icons-material/DragIndicator";
import { makeStyles } from "@material-ui/core";


const useStyles = makeStyles((theme) => ({
    search: {
      display: 'flex',
      boxShadow: '0px 4px 30px rgba(0, 0, 0, 0.25)',
    },
    saveBtn: {
      marginLeft: 'auto',
    },
    inputInput: {
      padding: '0 10px',
    },
    lstSec: {padding: '40px 0'}
  }));

export const NewAlertList = (props) => {
    

  return (
    <div>
        <Grid container spacing={0}>
          <Grid item xs={10} lg={1} className="p-0">
            <List sx={{ textAlign: "right" }}>
              <ListItem>
                <ListItemAvatar>
                  <Avatar>{props.num}</Avatar>
                </ListItemAvatar>
              </ListItem>
            </List>
          </Grid>
          <Grid item xs={10} lg={8} className="p-0">
            <List
              sx={{ width: "100%", maxWidth: 560, bgcolor: "background.paper" }}
            >
              <ListItem
                sx={{
                  width: "100%",
                  maxWidth: 560,
                  bgcolor: "background.paper",
                  boxShadow: "0px 4px 30px rgb(0 0 0 / 25%)",
                }}
              >
                <ListItemText primary={props.title}/>
                <ListItemAvatar>
                  <DragIndicatorIcon />
                </ListItemAvatar>
              </ListItem>
            </List>
          </Grid>
        </Grid>

    </div>
  );
};
